# WNBA 2026 Her Hoop Stats Cap Sheet Validation Report
## Source and scope
- Source cited in the extract: Her Hoop Stats WNBA Salary Cap Database.
- Input file: `wnba_2026_cap_sheet_long.csv`.
- Teams covered: 15.
- Output includes all extracted contract years available in the source table: 2026–2030.
- Important source note: values are cap hit, not base salary.

## Major limitation
The original extraction file does **not** preserve the row-level image/icon metadata from the Her Hoop Stats table. It preserves player rows, years, salary/cap/team percentages, free-agent/status labels, team-total rows, unsigned-draftee sections, and CBA rows, but not the actual `img src`, `alt`, `title`, or `aria-label` values for each row.

Because of that, exact icon preservation is not possible from this file alone. The outputs use these methods instead:
- `Draftee` is inferred when a row appears under the `Unsigned Draftees` section.
- `Protected Veteran` is inferred only when a subset of counted player salaries exactly matches both `Total Guaranteed Salary` and `Total Protected Veterans`.
- Rows excluded from team totals are flagged as likely `TC/D`, but exact Training Camp vs Draftee status is ambiguous unless raw HTML icon attributes are provided.
- Team Option icons are not recoverable from the original CSV.

## Validation summary
- 2026 team-total validation passed for 14/15 teams.
- Counted-row subset inference statuses across all years: `{'multiple_exact_solutions': 44, 'unique_exact_solution': 30, 'no_exact_solution': 1}`.
- Protected-veteran inference statuses across all years: `{'unique_exact_solution': 57, 'no_exact_solution': 12, 'multiple_exact_solutions': 6}`.
- Rows with inferred or section-derived icon/status signals: 325.
- Rows where exact row-level icon remains unavailable: 558.

## Files returned
- `wnba_2026_cap_sheet_player_team_season_validated.csv` — requested clean player/team/year file, all extracted years.
- `wnba_2026_cap_sheet_player_team_season_2026_only.csv` — 2026-only player/team file.
- `contracts_2026.csv` — schema-ready contract table using cap hit as reliable money field.
- `team_salary_cap.csv` — schema-ready team cap table.
- `validation_report_detail.csv` — validation by team/year.
- `validation_report_2026_summary.csv` — current-season summary validation.
- `missing_ambiguous_icon_rows.csv` — rows where exact row-level icon cannot be recovered.
- `field_coverage_audit.csv` — coverage of schema fields.
- `cba_numbers_by_team.csv` — extracted CBA constants by team page.

## 2026 validation by team
| Team | Salaries Pass | Players Pass | Cap Room Pass | Counted Subset | Protected Vet Inference |
|---|---:|---:|---:|---|---|
| Atlanta Dream | True | True | True | multiple_exact_solutions | unique_exact_solution |
| Chicago Sky | True | True | True | unique_exact_solution | no_exact_solution |
| Connecticut Sun | True | True | True | multiple_exact_solutions | no_exact_solution |
| Dallas Wings | True | True | True | multiple_exact_solutions | no_exact_solution |
| Golden State Valkyries | True | True | True | multiple_exact_solutions | multiple_exact_solutions |
| Indiana Fever | True | True | True | multiple_exact_solutions | unique_exact_solution |
| Las Vegas Aces | True | True | True | unique_exact_solution | unique_exact_solution |
| Los Angeles Sparks | True | True | True | multiple_exact_solutions | unique_exact_solution |
| Minnesota Lynx | True | True | True | multiple_exact_solutions | no_exact_solution |
| New York Liberty | True | True | True | multiple_exact_solutions | multiple_exact_solutions |
| Phoenix Mercury | False | False | False | no_exact_solution | no_exact_solution |
| Portland Fire | True | True | True | multiple_exact_solutions | unique_exact_solution |
| Seattle Storm | True | True | True | multiple_exact_solutions | no_exact_solution |
| Toronto Tempo | True | True | True | multiple_exact_solutions | no_exact_solution |
| Washington Mystics | True | True | True | multiple_exact_solutions | no_exact_solution |

## Fields that could not be fully recovered from the original CSV
### contracts_2026
- Exact `contract_icon` for every player row.
- `option_flag` / Team Option exact icon.
- Exact `tc_flag` versus draftee for non-counted main-table rows.
- `salary` as base salary; source explicitly gives cap hit.
- `contract_length_years`, `contract_start_year`, `contract_end_year`.
- `free_agent_type_prior`, `signed_date`, `prior_team`, `prior_salary_2025`, `salary_raise_amount`, `salary_raise_pct`.

### team_salary_cap
- `dead_cap`.
- Exact minimum salary count if non-counted TC/D rows should be handled differently than inferred counted rows.

## Recommendation
For a truly icon-preserved version, export or attach the raw HTML for each team page. The row-level icon information must come from image attributes or CSS/HTML surrounding the salary cells; it is not present in the original CSV.
