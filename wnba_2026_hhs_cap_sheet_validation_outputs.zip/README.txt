WNBA 2026 HHS cap sheet validation outputs

Primary output: wnba_2026_cap_sheet_player_team_season_validated.csv
Schema outputs: contracts_2026.csv and team_salary_cap.csv
Validation report: VALIDATION_REPORT.md

Important: original CSV does not preserve raw row-level icon metadata. Contract icons are inferred where possible and explicitly flagged by contract_icon_source.
